@extends('layout.app')
@section('content')
    <div class="content-wrapper">
        <div class="container-fluid flex-grow-1 container-p-y">
            <div class="row">
                <div class="col-lg-12 mb-4 order-0">
                    <h4>Order Status Update</h4>
                    <div class="row">
                        <div class="col-sm-2 left_right_none">
                            <div class="form-group mt-4">

                                <input type="text"
                                    class="form-control datetimepicker4" name="from" placeholder="Enter CN No">
                            </div>
                        </div>

                        <div class="col-sm-2 ">
                            <div class="form-group">
                                <input type="submit" name="submit" value="Enter"
                                    class="btn btn-info" style="margin-top: 25px;padding:10px;width: 50%;">
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="d-flex align-items-end row">
                            <div class="col-12">
                                <div class="card-body">
                                    <div class="panel panel-default ">



                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

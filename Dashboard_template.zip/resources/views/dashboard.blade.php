@extends('layout.app')
@section('content')
    <div class="content-wrapper">
        <!-- Content -->

        <div class="container-xxl flex-grow-1 container-p-y">
            <div class="row">
                <p>Login successfully</p>
            </div>
            <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
    </div>
@endsection
